import React from 'react'

function MypageModal() {

  return (
    <div className='mypage_container'>This is Mypage component</div>
  )
}

export default MypageModal